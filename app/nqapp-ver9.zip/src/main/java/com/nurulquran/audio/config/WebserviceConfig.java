package com.nurulquran.audio.config;

public class WebserviceConfig {
	
	public static String URL_SONG="http://";
	public static String URL_IMAGE;
	public static String URL_NEXT_PAGE;
}
