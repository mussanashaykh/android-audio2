package com.nurulquran.audio.gcm;

/**
 * Created by pham on 04/12/2015.
 */
public class Args {

    public static final String SENT_TOKEN_TO_SERVER = "sendTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String NOTIFICATION = "notification";
    public static final String SENDER_ID="778464182544";

}
