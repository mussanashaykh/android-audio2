package com.nurulquran.audio.interfaces;

/**
 * Created by pham on 22/05/2016.
 */
public interface MediaNotification {
    void onClickMediaNotification();
}
