package com.nurulquran.audio.interfaces;

/**
 * Created by pham on 04/05/2016.
 */
public interface LayoutFooter {
    void onListenerFooter();
}
